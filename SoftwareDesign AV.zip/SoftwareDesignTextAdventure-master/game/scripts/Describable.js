"use strict";
var game;
(function (game) {
    class Describable {
    }
    game.Describable = Describable;
})(game || (game = {}));
//# sourceMappingURL=Describable.js.map
# SoftwareDesignTextAdventure

## Installation:
Das spiel kann als einfache html anwendung ausgeführt werden. Um zu spielen, muss lediglich die game.html datei geöffnet werden.

Das Konzept ist [hier zu finden](https://github.com/AljoshaVieth/SoftwareDesignTextAdventure/blob/master/concept/TextAdventure.pdf).

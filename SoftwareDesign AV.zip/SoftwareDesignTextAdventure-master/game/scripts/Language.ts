namespace game {
    export enum Language {
        ENGLISH,
        GERMAN,
        FRENSH
    }
}
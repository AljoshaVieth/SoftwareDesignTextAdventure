"use strict";
var game;
(function (game) {
    let Language;
    (function (Language) {
        Language[Language["ENGLISH"] = 0] = "ENGLISH";
        Language[Language["GERMAN"] = 1] = "GERMAN";
        Language[Language["FRENSH"] = 2] = "FRENSH";
    })(Language = game.Language || (game.Language = {}));
})(game || (game = {}));
//# sourceMappingURL=Language.js.map
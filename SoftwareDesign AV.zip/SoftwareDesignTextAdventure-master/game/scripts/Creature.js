"use strict";
var game;
(function (game) {
    class Creature extends game.Describable {
    }
    game.Creature = Creature;
})(game || (game = {}));
//# sourceMappingURL=Creature.js.map
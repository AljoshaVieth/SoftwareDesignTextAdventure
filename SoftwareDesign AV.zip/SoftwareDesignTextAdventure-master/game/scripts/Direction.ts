namespace game{
    export enum Direction {
        NORTH= "NORTH",
        EAST = "EAST",
        WEST = "WEST",
        SOUTH = "SOUTH"
    }
}
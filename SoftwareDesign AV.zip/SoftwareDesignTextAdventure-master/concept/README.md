#Concepts
The drawio files contain concepts for the game as well as UML diagrams.

namespace game {
    export class Creature extends Describable{
        public position: Room;
    }
}
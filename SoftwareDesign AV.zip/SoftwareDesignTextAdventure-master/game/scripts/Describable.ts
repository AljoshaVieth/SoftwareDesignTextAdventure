namespace game {
    export class Describable {
        public description: string;
        public name: string;
    }
}
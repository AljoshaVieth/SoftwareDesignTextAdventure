"use strict";
var game;
(function (game) {
    let Direction;
    (function (Direction) {
        Direction["NORTH"] = "NORTH";
        Direction["EAST"] = "EAST";
        Direction["WEST"] = "WEST";
        Direction["SOUTH"] = "SOUTH";
    })(Direction = game.Direction || (game.Direction = {}));
})(game || (game = {}));
//# sourceMappingURL=Direction.js.map